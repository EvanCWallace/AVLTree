/**
 * 							DESCRIPTION:
 * This is a class file, Notebook, for the source folder NotebookTest.
 * This file will contain methods to get, set, add, and traverse 
 * a collection set of ArrayList. This file will allow the main driver file,
 * NotebookTest, to run functionally.
 * 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * *					 CLASS IMPORTS:                      * *
 * *														 * *
 * *  java.util.ArrayList									 * *
 * *														 * *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * *					 CLASS VARIABLES:                    * *
 * *														 * *
 * *  -notes	   											 * *
 * *													     * *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * *                     CLASS METHODS:                      * *
 * * 														 * *
 * *  #Notebook(): 											 * *
 * * 														 * *
 * *  #getNotes(): String									 * *
 * * 														 * *
 * *  #getNote(int): String                                  * *
 * *														 * *
 * *  #getNoteNumber(String): int    						 * *
 * *														 * *
 * *  #setNotes(ArrayList<String>):							 * *
 * * 														 * *
 * *  #setNote(int, String):		                         * *
 * * 														 * *
 * *  #addNote(String):										 * *
 * * 														 * *
 * *  #numberOfNotes(): int									 * *
 * * 														 * *
 * *  #deleteNote(int):										 * *
 * * 														 * *
 * *  #moveNoteUp(int):										 * *
 * * 														 * *
 * *  #moveNoteDown(int):									 * *
 * * 														 * *
 * *  #moveNoteToTop(int):									 * *
 * *  														 * *
 * *  #moveNoteToBottom(int):    							 * *
 * *  														 * *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * 
 * 
 *    @author Evan Wallace
 */
package noteApp;

import java.util.ArrayList;

public class Notebook 
{
    private ArrayList<String> notes;
    
    /**
     * Notebook()
     * CONSTRUCTOR
     * 
     * This is a constructor method designed to initialize
     * any declared objects for the class.
     * 
     * 
     * this.notes is initialized to a new ArrayList<Strings>
     * this.notes is at a default capacity of 10
     * 		Once the capacity of the ArrayList is reached
     * 		ArrayList will auto-resize
     * this.notes is filled with NULL Strings
     * 
     */
    protected Notebook()
    {
        this.notes = new ArrayList<String>(); 
    }
    
    /**
     * getNotes()
     * GETTER METHOD
     * 
     * This is a getter method designed to return the toString()
     * form of the ArrayList<String> notes
     * 
     * EXAMPLE:
     * [NULL, NULL, NULL, NULL, NULL, etc...]
     * 
     * @return notes
     */
    protected ArrayList<String> getNotes()
    {
        return notes;
    }
    
    
    /**
     * getNote(int)
     * GETTER METHOD
     * 
     * This is a getter method designed to return the String value
     * at the position of a note within the ArrayList<String> notes.
     * The method passes an integer value in order to target a position
     * within the ArrayList<String> notes.
     * 
     * .get()
     * Overrides: get(...) in AbstractList
     * Parameters:index index of the element to return
     * Returns:the element at the specified position in this list
     * Throws:IndexOutOfBoundsException - if the index is out of range
     * 									  (index < 0 || index >= size())
     * 
     * EXAMPLE:
     * if position = 0
     * then the method should return the String allocated at position 0
     * 
     * @param position
     * @return this.notes.get(position)
     */
    protected String getNote(int position)
    {
        return this.notes.get(position);
    }
    
    /**
     * getNoteNumber(String)
     * GETTER METHOD
     * 
     * This is a getter method designed to return a positional value
     * of a specified note within the ArrayList<String> notes.
     * This is given by passing a String value into the parameter of
     * the getter method. Once the specified String has been located within
     * the ArrayList<String> notes, then the method returns the integer value
     * of the position.
     * 
     * .indexOf
     * Overrides: indexOf(...) in AbstractList
     * Parameters:o element to search for
     * Returns:the index of the first occurrence of the specified element in this list,
     *         or -1 if this list does not contain the element
     * 
     * @param e
     * @return this.notes.indexOf(e)
     */
    protected int getNoteNumber(String e)
    {
       return this.notes.indexOf(e);
    }
    
    /**
     * setNotes(ArrayList<String>)
     * SETTER METHOD
     * 
     * This is a setter method that allows the ArrayList<String> notes
     * to be filled with a specified String newNote. The note is appended
     * to the ArrayList,String> notes at the tail of the list.
     * 
     * @param newNote
     */
    protected void setNotes(ArrayList<String> newNote)
    {
        this.notes = newNote;
    }
    
    /**
     * setNote(int, String)
     * SETTER METHOD
     * 
     * This is a setter method that allows the ArrayList<String> notes
     * to be filled with a specified String e at ANY integer position within
     * the list.
     * 
     * .set()
     * Overrides: set(...) in AbstractList
     * Parameters:index index of the element to replace
     * 			  element element to be stored at the specified position
     * Returns:the element previously at the specified position
     * Throws:IndexOutOfBoundsException - if the index is out of range
     * 									  (index < 0 || index >= size())
     * @param position
     * @param e
     */
    protected void setNote(int position, String e)
    {
        this.notes.set(position, e);
    }
    
    /**
     * addNote(String)
     * FUNCTIONALITY METHOD
     * 
     * This is a functional method that allows the user to add a note to the
     * ArrayList<String> notes if and only if the note is not already within
     * the list.
     * 
     * .contains()
     * Overrides: contains(...) in AbstractCollection
     * Parameters:o element whose presence in this list is to be tested
     * Returns:true if this list contains the specified element
     * 
     * .add()
     * Overrides: add(...) in AbstractList
     * Parameters:e element to be appended to this list
     * Returns:true (as specified by Collection.add)
     * 
     * 
     * @param note
     */
    protected void addNote(String note)
    {
        if(!notes.contains(note))
            this.notes.add(note);
    }
    
    /**
     * deleteNote(int)
     * FUNCTIONALITY METHOD
     * 
     * This is a functional method that allows the user to delete a note
     * within the ArrayList<String> notes.
     * 
     * .remove()
     * Overrides: remove(...) in AbstractList
     * Parameters:index the index of the element to be removed
     * Returns:the element that was removed from the list
     * Throws:IndexOutOfBoundsException - if the index is out of range
     * 									  (index < 0 || index >= size())
     * 
     * @param position
     */
    protected void deleteNote(int position)
    {
        notes.remove(position);
    }
    
    /**
     * numberOfNotes()
     * FUNCTIONALITY METHOD
     * 
     * This is a functional method that provides the user with the integer value of notes
     * within the ArrayList<String> notes.
     * 
     * .size()
     * Overrides: size() in AbstractCollection
     * Returns: the number of elements in this list
     * 
     * @return this.notes.size()
     */
    protected int numberOfNotes()
    {
        return this.notes.size();
    }
    
    /**
     * moveNoteUp(int)
     * FUNCTIONALITY METHOD
     * 
     * This is a functional method that moves a note up in the ArrayList<String> notes.
     * String toMove is a temp variable to swap out the information without
     * losing data.
     * 
     * .set()
     * Overrides: set(...) in AbstractList
     * Parameters:index index of the element to replace
     * 			  element element to be stored at the specified position
     * Returns:the element previously at the specified position
     * Throws:IndexOutOfBoundsException - if the index is out of range
     * 									  (index < 0 || index >= size())
     * 
     * .get()
     * Overrides: get(...) in AbstractList
     * Parameters:index index of the element to return
     * Returns:the element at the specified position in this list
     * Throws:IndexOutOfBoundsException - if the index is out of range
     * 									  (index < 0 || index >= size())
     * 
     * @param position
     */
    protected void moveNoteUp(int position)
    {
        if(position > 0)
        {
            String toMove = this.notes.get(position);
            notes.set(position, this.notes.get(position - 1));
            notes.set( (position - 1) , toMove);
        }
    }
    
    /**
     * moveNoteDown(int)
     * FUNCTIONALITY METHOD
     * 
     * This is a functional method that moves a note down in the ArrayList<String> notes.
     * String toMove is a temp variable to swap out the information without
     * losing data.
     * 
     * .set()
     * Overrides: set(...) in AbstractList
     * Parameters:index index of the element to replace
     * 			  element element to be stored at the specified position
     * Returns:the element previously at the specified position
     * Throws:IndexOutOfBoundsException - if the index is out of range
     * 									  (index < 0 || index >= size())
     * 
     * .get()
     * Overrides: get(...) in AbstractList
     * Parameters:index index of the element to return
     * Returns:the element at the specified position in this list
     * Throws:IndexOutOfBoundsException - if the index is out of range
     * 									  (index < 0 || index >= size())
     * 
     * @param position
     */
    protected void moveNoteDown(int position)
    {
        if(position <= notes.size())
        {
            String toMove = notes.get(position);
            notes.set(position, notes.get(position + 1));
            notes.set( (position + 1) , toMove);
        }
    }
    
    /**
     * moveNoteToTop(int)
     * FUNCTIONALITY METHOD
     * 
     * This is a functional method that moves a note to the top of 
     * the ArrayList<String> notes.
     * String toMove is a temp variable to swap out the information without
     * losing data.
     * 
     * .set()
     * Overrides: set(...) in AbstractList
     * Parameters:index index of the element to replace
     * 			  element element to be stored at the specified position
     * Returns:the element previously at the specified position
     * Throws:IndexOutOfBoundsException - if the index is out of range
     * 									  (index < 0 || index >= size())
     * 
     * .get()
     * Overrides: get(...) in AbstractList
     * Parameters:index index of the element to return
     * Returns:the element at the specified position in this list
     * Throws:IndexOutOfBoundsException - if the index is out of range
     * 									  (index < 0 || index >= size())
     * 
     * @param position
     */
    protected void moveNoteToTop(int position)
    {
        if(position > 0)
        {
            String toMove = this.notes.get(position);
            notes.set(position, this.notes.get(position - 1));
            notes.set( (0) , toMove);
        }
    }
    
    
    /**
     * moveNoteToBottom(int)
     * FUNCTIONALITY METHOD
     * 
     * This is a functional method that moves a note to the bottom of
     * the ArrayList<String> notes.
     * String toMove is a temp variable to swap out the information without
     * losing data.
     * 
     * .set()
     * Overrides: set(...) in AbstractList
     * Parameters:index index of the element to replace
     * 			  element element to be stored at the specified position
     * Returns:the element previously at the specified position
     * Throws:IndexOutOfBoundsException - if the index is out of range
     * 									  (index < 0 || index >= size())
     * 
     * .get()
     * Overrides: get(...) in AbstractList
     * Parameters:index index of the element to return
     * Returns:the element at the specified position in this list
     * Throws:IndexOutOfBoundsException - if the index is out of range
     * 									  (index < 0 || index >= size())
     * 
     * .size()
     * Overrides: size() in AbstractCollection
     * Returns: the number of elements in this list
     * 
     * @param position
     */
    protected void moveNoteToBottom(int position)
    {
        if(position <= notes.size())
        {
            String toMove = notes.get(position);
            notes.set(position, notes.get(position + 1));
            notes.set( (notes.size()-1) , toMove);
        }
    }
}
