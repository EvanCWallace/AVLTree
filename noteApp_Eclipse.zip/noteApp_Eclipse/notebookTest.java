/**
 * This is the driver file for the noteApp Java project
 * 
 * @author Evan Wallace
 */
package noteApp;

import java.util.Iterator;
import java.util.ListIterator;

public class notebookTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
    					//new instance of object myBook
        Notebook myBook = new Notebook();
		
        				//Appending information into myBook
		myBook.addNote("Read Chapter 12");
		myBook.addNote("Take dog to the vet");
		myBook.addNote("Empty and clean refrigerator");
		myBook.addNote("Buy more firewood");
		myBook.addNote("Make dentist appointment.");
		myBook.addNote("Clean out the garage");
                
                	    // Test of loop with Iterator
		Iterator<String> it = myBook.getNotes().iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println();
		
					    // No cleaning!!!
		String searchString = "clean";
			// Iterators once used cannot be reset, so reinstantiate
		it = myBook.getNotes().iterator();
		while (it.hasNext()) {
			if (it.next().toLowerCase().contains(searchString)) {
				it.remove();
			}
		}
		
		it = myBook.getNotes().iterator();
		
		while (it.hasNext()) System.out.println(it.next());
		System.out.println();
		
		
					// ListIterators have more available methods
		searchString = "dog";
		boolean found = false;
		ListIterator<String> listIt = myBook.getNotes().listIterator();
		while (listIt.hasNext() && !found) {
			if (listIt.next().contains(searchString)) found = true;			
		}
		
			// The iterator moves once it processes an item with hasNext()
		int targetIndex = listIt.previousIndex();
		
		System.out.printf("\nBefore you %s, you must %s.", 
				           myBook.getNotes().get(targetIndex), 
				           myBook.getNotes().get(targetIndex-1));
		System.out.printf("\nAfter you %s, you must %s.", 
		           listIt.previous(), myBook.getNotes().get(targetIndex+1)); 
							// Note use of .previous()
                
				//Testing the my Notebook Class and methods
                System.out.println();
                System.out.println(myBook.numberOfNotes());
                System.out.println(myBook.getNotes());
                System.out.println();
                myBook.deleteNote(1);
                System.out.println(myBook.getNotes());
                System.out.println(myBook.getNoteNumber("Buy more firewood"));
                myBook.setNote(0, "WORKS");
                System.out.println(myBook.getNote(0));
                myBook.addNote("WORKS");
                System.out.println(myBook.getNotes());
                
                //For loop to test a note moving 2 times
                for(int i = 0; i <2; i++)
                {
                    myBook.moveNoteDown(i);
                }
                System.out.println(myBook.getNotes());
                
                myBook.moveNoteToBottom(0);
                System.out.println(myBook.getNotes());
    }
    
}

