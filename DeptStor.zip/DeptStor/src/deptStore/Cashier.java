package deptStore;

/**
 * A class to create a Cashier working at a store
 * 
 * @author OOPDA Instructor
 * @author Evan Wallace
 * 
 * Date Modified: 03/03/2021
 */
public class Cashier extends Employee {
	
	/**
	 * Declared Protected Variable Fields for the cashier:
	 * 
	 * int employee ID
	 * double hourlyWage, drawerAmount, transActions
	 * 
	 */
	protected int employeeID;
	protected double hourlyWage, drawerAmount, transActions;

	/**
	 * Getter for the Protected Variable employeeID:
	 * 
	 * returns this instance of the employee ID.
	 * 
	 * @return
	 */
	protected int getEmployeeID() {
		return employeeID;
	}

	/**
	 * Setter for the Protected variable employeeID:
	 * 
	 * Sets the protected variable to the current employee ID.
	 * 
	 * @param employeeID
	 */
	protected void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}

	/**
	 * Getter for the Protected Variable hourlyWage:
	 * 
	 * returns the current instance of this employee's
	 * hourly wage.
	 * 
	 * @return hourlyWage
	 */
	protected double getHourlyWage() {
		return hourlyWage;
	}

	/**
	 * Setter for the Protected Variable hourlyWage:
	 * 
	 * Sets the protected variable to the current current
	 * employee's hourly wage.
	 * 
	 * @param hourlyWage
	 */
	protected void setHourlyWage(double hourlyWage) {
		this.hourlyWage = hourlyWage;
	}

	/**
	 * Class Constructor:
	 * 
	 * This constructor calls the super class with the employee's name.
	 * The constructor also sets the protected filed variables to their
	 * appropriate values.
	 * 
	 * @param name
	 * @param employeeID
	 * @param hourlyWage
	 * @param drawerAmount
	 */
	public Cashier(String name, int employeeID, double hourlyWage, double drawerAmount) {
		
		super(name);
		setEmployeeID(employeeID);
		setHourlyWage(hourlyWage);
		this.drawerAmount = drawerAmount;
	}

	/**
	 * ringup():
	 * 
	 * This method is designed to keep track of the total amount of
	 * money accumulated.
	 * Transactions is incremented by one.
	 * 
	 * @param d
	 */
	public void ringup(double d) {
		// TODO Auto-generated method stub
		this.transActions += 1;
		this.drawerAmount += d;
		
	}

	/**
	 * completeReturns:
	 * 
	 * This method is designed to keep track of the total money taken
	 * from the drawer.
	 * Transactions is incremented by one.
	 *  
	 * @param d
	 */
	public void completeReturn(double d) {
		// TODO Auto-generated method stub
		this.transActions += 1;
		this.drawerAmount -= d;
	}
	
	/**
	 * Productivity():
	 * 
	 * This method is designed to return the percentage value of
	 * the productivity of the employee.
	 * 
	 * Goal of 20 Transactions
	 * 
	 * @return metricProductivity
	 */
	public double Productivity(){
		
		double transActionsTarget = 20;
		
		double metricProductivity = (100) * (this.transActions / transActionsTarget);
		
		
		return metricProductivity;
	}
	
	/**
	 * toString():
	 * 
	 * returns a custom prompt to the console
	 * 
	 * @return Custom String
	 */
	public String toString()
	{
		return "Name: " + name + "\n" +
			   "ID: " + getEmployeeID() + "\n" +
			   "Hourly Wage: " + getHourlyWage() + "\n" +
			   "Productivity: " + Productivity() + "%\n" +
			   "Drawer Amount: " + this.drawerAmount + "\n" +
			   "Transactions: " + this.transActions + "\n";
		
	}
}

