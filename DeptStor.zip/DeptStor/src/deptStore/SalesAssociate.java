package deptStore;

/**
 * A class to create a SalesAssociate working at a store
 * 
 * @author OOPDA Instructor
 * @author Evan Wallace
 * 
 * Date Modified: 03/03/2021
 *
 */
public class SalesAssociate extends Employee {

	protected int employeeID, sales;
	protected double hourlyWage, revenueTotal;
	
	protected String department;
	
	protected int getEmployeeID() {
		return employeeID;
	}

	protected void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}

	protected double getHourlyWage() {
		return hourlyWage;
	}

	protected void setHourlyWage(double hourlyWage) {
		this.hourlyWage = hourlyWage;
	}

	protected String getDepartment() {
		return department;
	}

	protected void setDepartment(String department) {
		this.department = department;
	}

	public SalesAssociate(String name, int employeeID, double hourlyWage, String department) {
		// TODO Auto-generated constructor stub
		super(name);
		
		setEmployeeID(employeeID);
		setHourlyWage(hourlyWage);
		
		setDepartment(department);
	}

	public void makeSale(double randomAmount) {
		// TODO Auto-generated method stub	
		this.sales += 1;
		this.revenueTotal += randomAmount;
	}
	
	public double Productivity(){
		
		int salesTarget = 3;
		double revenueTarget = 1000.00;
		
		double salesMetric = (100) * (sales / salesTarget);
		
		double revenueMetric = (100) * (revenueTotal / revenueTarget);
		
		double metricAverage = (salesMetric + revenueMetric) / 2;
		
		return metricAverage;
	}
	
	public String toString()
	{
		return "Name: " + name + "\n" +
			   "ID: " + getEmployeeID() + "\n" +
			   "Hourly Wage: " + getHourlyWage() + "\n" +
			   "Productivity: " + Productivity() + "%\n" +
			   "Department: " + getDepartment() + "\n" +
			   "Number of Sales: " + this.sales + "\n" +
			   "Amount of Revenue: " + this.revenueTotal + "\n";
		
	}
}
