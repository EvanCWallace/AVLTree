
import java.util.HashMap;
import java.util.function.Predicate;

/**
 * @author Evan Wallace
 *
 */
public class Person {
	
	private static long id = 916421998;
	private String firstName, middleName, lastName, 
				   email,     ssn;
	private static int age;
	
	/**
	 * Constructor for the file Person
	 * 
	 * @param firstName
	 * @param middleName
	 * @param lastName
	 * @param email
	 * @param ssn
	 * @param age
	 */
	public Person(String firstName, String  middleName, String lastName, 
			   	  String email,     String  ssn       ,  int age){
		
		
		setFirstName(firstName);
		setMiddleName(middleName);
		setLastName(lastName);
		setEmail(email);
		setSsn(ssn);
		setAge(age);
			
	}
	
	/**
	 * Validates the email entered by the user
	 * @param email
	 * @return
	 */
	public static boolean validateEmail(String email) {
		String validEmail = "^(.+)@(.+)$";
		return email.matches(validEmail);
	}
	
	/**
	 * Validates the age entered by the user
	 * @param age
	 * @return
	 */
	public static boolean validateAge(int age) {		
		return (age >= 16);
	}
	
	/**
	 * validates the full name entered by the user
	 * @param firstName
	 * @param middleName
	 * @param lastName
	 * @return
	 */
	public static boolean validateName(String firstName, String middleName, String lastName) {		
		String name;
		
		if(middleName != null)
			name = firstName + " " + middleName + " "+ lastName;
		else
			name = firstName + " " + lastName;
		
		return name.matches("(?i)[a-z]([- ',.a-z]{0,23}[a-z])?");
	}
	
	/**
	 * validates the ssn entered by the user
	 * @param ssn
	 * @return
	 */
	public static boolean validateSsn(String ssn)
	{
		return ssn.matches("^\\d{3}[-]?\\d{2}[-]?\\d{4}$");
	}
	
	public static HashMap<String, Predicate<Person>> personMod;
	
	/**
	 * 
	 */
	static {
		personMod = new HashMap<>();
	}
	
	/**
	 * Checks to see who is the oldest person in the map
	 * @param age
	 * @return
	 */
	
	public static Predicate<Person> isAgeMoreThan(int age) 
	{
	    return p -> p.getAge() > age;
	}
	
	/**
	 * Checks to see who is the youngest in the map
	 * @param age
	 * @return
	 */
	public static Predicate<Person> isAgeLessThan(int age) 
	{
	    return p -> p.getAge() < age;
	}
	
	
	/**
	 * 
	 * @return
	 */
	public static  long getId() {
		id += 1;
		return id;
	}
	
	/**
	 * 
	 * @return
	 */
	protected String getFirstName() {
		return firstName;
	}
	
	/**
	 * 
	 * @param firstName
	 */
	protected void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	/**
	 * 
	 * @return
	 */
	protected String getMiddleName() {
		return middleName;
	}
	
	/**
	 * 
	 * @param middleName
	 */
	protected void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	
	/**
	 * 
	 * @return
	 */
	protected String getLastName() {
		return lastName;
	}
	
	/**
	 * 
	 * @param lastName
	 */
	protected void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	/**
	 * 
	 * @return
	 */
	protected String getEmail() {
		return email;
	}
	
	/**
	 * 
	 * @param email
	 */
	protected void setEmail(String email) {
		this.email = email;
	}
	
	/**
	 * 
	 * @return
	 */
	protected String getEmailDomain() {
		int domainIndex = email.indexOf("@");
		String domain = email.substring(domainIndex + 1);
		return domain;
	}
	
	
	/**
	 * 
	 * @return
	 */
	protected String getLast4Ssn()
	{
		return ssn.substring(7);
	}
	
	/**
	 * 
	 * @return
	 */
	protected String getSsn() {
		return ssn;
	}
	
	/**
	 * 
	 * @param ssn
	 */
	protected void setSsn(String ssn) {
		this.ssn = ssn;
	}
	
	/**
	 * 
	 * @return
	 */
	protected int getAge() {
		return age;
	}
	/**
	 * 
	 * @param age
	 */
	protected void setAge(int age) {
		this.age = age;
	}
	
	
	/**
	 * Custom toString for the console
	 */
	@Override
	public String toString() {
		if(this.middleName == null)
		{
			return getFirstName() + " " 
		         + getLastName()  + " " +
					"(Person)"    + "\n"+
		         getEmailDomain() + "\n"+
				 getLast4Ssn()    + "\n"+
				 "Mapping\n";
		}
		else
		{
			return getFirstName()   + " " 
		         + getMiddleName()  + " "
		         + getLastName()    + " " +
				 "(Person)"+ "\n"+
		         getEmailDomain() + "\n"+
				 getLast4Ssn()    + "\n"+
		         "Mapping\n";
		}
	}
}
