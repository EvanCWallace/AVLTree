import java.util.HashMap;
import java.util.Scanner;

/**
 * @author Evan Wallace
 *
 */
public class Driver {
	private static HashMap<Long, Person> person = new HashMap<>();
	private static boolean invaildInputFlag = false;

	
	/**
	 * Runs the private static methods in the main driver file
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		do {
		userPrompt(sc);
		}while(invaildInputFlag);
		sc.close();
		makeStudent();
		makeInstructor();
		displayPerson();
		

		System.out.println("\n--------------------------------\n");
		//TODO complete this method
		Person.personMod.forEach((x , y) -> {
			System.out.println(x +": " + y);
		});
		
	}
	
	/**
	 * 
	 * @param sc
	 * 
	 * Asks for the users input
	 */
	private static void userPrompt(Scanner sc) {
		System.out.println("How should we evaluate? "
		         + " [Enter 'oldest' or 'youngest']\n");
		String evaluatorType = sc.nextLine();
		System.out.println("Enter Person's first name\n");
		String firstName = sc.nextLine();
		System.out.println("Enter Person's middle name\n");
		String middleName = sc.nextLine();
		System.out.println("Enter Person's last name\n");
		String lastName = sc.nextLine();
		System.out.println("Enter Person's email address\n");
		String email = sc.nextLine();
		System.out.println("Enter person's SSN in ###-##-#### format\n");
		String SSN = sc.nextLine();
		System.out.println("Enter person's age\n");
		int age = sc.nextInt();

		makePerson(firstName, middleName, lastName,
				   email,     SSN,        age,
		           evaluatorType, sc);
	}
	
	/**
	 * @param firstName
	 * @param middleName
	 * @param lastName
	 * @param email
	 * @param SSN
	 * @param age
	 * @param evaluatorType
	 * @param sc
	 * 
	 * Makes a person for the user's input
	 */
	private static void makePerson(String firstName, String middleName, String lastName,
								   String email,     String SSN,        int age,
								   String evaluatorType,                Scanner sc) {
		
		if(Person.validateName(firstName, middleName, lastName)
		&& Person.validateEmail(email)
		&& Person.validateSsn(SSN)
		&& Person.validateAge(age))
		{
			invaildInputFlag = false;
			Person newPerson = new Person(firstName, middleName, lastName,
					                      email,     SSN,        age);
			person.put(Person.getId(), newPerson);
			
			if(evaluatorType.equals("oldest"))
				Person.personMod.put(evaluatorType, Person.isAgeMoreThan(age));
			if(evaluatorType.equals("youngest"))
				Person.personMod.put(evaluatorType, Person.isAgeLessThan(age));
		}
		else
		{
			if(Person.validateName(firstName, middleName, lastName) == false)
				System.out.println("Invaild Input: Name");
			else if(Person.validateEmail(email) == false)
				System.out.println("Invaild Input: email");
			else if(Person.validateSsn(SSN)     == false)
		    	System.out.println("Invaild Input: SSN");
			else if(Person.validateAge(age)     == false)
		    	System.out.println("Invaild Input: Age");
			invaildInputFlag = true;
		}
	}
	
	/**
	 * Hard Coded Student
	 */
	private static void makeStudent()
	{
		Student newStudent1 = new Student("Tom",         null, "Brady",        "tomBrady233@gmail.com",
				                         "124-75-9930",  36,   "Aviation");
		Student newStudent2 = new Student("Eric",        null, "Clapton",      "theClap365@hotmail.com",
                                          "647-29-0039", 55,   "Music");
		Student newStudent3 = new Student("John",        null, "Snow",         "theGameisSnow@outlook.com",
                                          "169-38-9020", 36,   "Aviation");
		
		person.put(Person.getId(), newStudent1);
		person.put(Person.getId(), newStudent2);
		person.put(Person.getId(), newStudent3);
	}
	
	/**
	 * Hard coded instructor
	 */
	private static void makeInstructor()
	{
		Instructor newInstructor1 = new Instructor("Micheal", "B.", "Anthony", "michealAnthony21@gmail.com",
				                                   "321-84-0393",    45,        "Musical Theator");
		
		Instructor newInstructor2 = new Instructor("Luke", null, "Skywalker", "lukeUsedTheForce43@yahoo.com",
				                                   "987-06-5432", 67,          "Jedi Master");
		
		Instructor newInstructor3 = new Instructor("Robert", "C.", "Wallace", "robertwall@phil.frb.org", 
				                                   "423-74-0200",   51,        "Cyber Security");
		
		person.put(Person.getId(), newInstructor1);
		person.put(Person.getId(), newInstructor2);
		person.put(Person.getId(), newInstructor3);
	}
	
	/**
	 * Displays the Person using lamda expressions
	 */
	private static void displayPerson() {
		System.out.println("\n--------------------------------\n");
		//TODO complete this method
		person.forEach((x , y) -> {
			System.out.println(x);
			System.out.println(y);
		});
	}
	
	
	

}
