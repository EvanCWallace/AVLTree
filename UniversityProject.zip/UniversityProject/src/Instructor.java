
public class Instructor extends Person{
	
	protected String department;
	
	/**
	 * @param firstName
	 * @param middleName
	 * @param lastName
	 * @param email
	 * @param ssn
	 * @param age
	 * @param department
	 */
	public Instructor(String firstName, String middleName, String lastName,
			          String email,     String ssn       , int age,
			          String department)
	{
		super(firstName, middleName, lastName, email, ssn, age);
		this.department = department;
		setDepartment(this.department);
	}

	/**
	 * 
	 * @return
	 */
	protected String getDepartment() {
		return department;
	}

	/**
	 * 
	 * @param department
	 */
	protected void setDepartment(String department) {
		this.department = department;
	}

	/**
	 * 
	 */
	@Override
	public String toString() {
		if(getMiddleName() == null)
		{
			return getFirstName()     + " " +
		           getLastName()      + " " +
					"(Instructor)"    +"\n" +
			         getEmailDomain() +"\n" +
					 getLast4Ssn()    +"\n" +
					 "Mapping"        +"\n" +
					 getDepartment()  +"\n" ;
		}
		else
		{
			return getFirstName()   + " " 
		         + getMiddleName()  + " "
		         + getLastName()    + " " +
				 "(Instructor)"     + "\n"+
		         getEmailDomain()   + "\n"+
				 getLast4Ssn()      + "\n"+
				 "Mapping"          +"\n" +
				 getDepartment()    +"\n";
		}
	}
}
