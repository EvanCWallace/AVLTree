
public class Student extends Person{
	
	protected String major;
	
	/**
	 * 
	 * @param firstName
	 * @param middleName
	 * @param lastName
	 * @param email
	 * @param ssn
	 * @param age
	 * @param major
	 */
	public Student (String firstName, String middleName, String lastName,
			        String email,     String ssn,        int age,
			        String major){
		
		super(firstName, middleName, lastName, email, ssn, age);
		this.major = major;
		
		setMajor(this.major);

	}

	/**
	 * 
	 * @return
	 */
	protected String getMajor() {
		return major;
	}

	/**
	 * 
	 * @param major
	 */
	protected void setMajor(String major) {
		this.major = major;
	}
	
	@Override
	public String toString() {
		if(getMiddleName() == null)
		{
			return getFirstName() + " " 
		         + getLastName()  + " " +
					"(Student)"   + "\n"+
			         getEmailDomain() + "\n"+
					 getLast4Ssn()    + "\n"+
					 "Mapping"        + "\n"+
					 getMajor()       +"\n";
		}
		else
		{
			return getFirstName()   + " " 
		         + getMiddleName()  + " "
		         + getLastName()    + " " +
				 "(Student)"+ "\n"+
		         getEmailDomain() + "\n"+
				 getLast4Ssn()    + "\n"+
				 "Mapping"        + "\n"+
				 getMajor()       +"\n";
		}
	}

}
