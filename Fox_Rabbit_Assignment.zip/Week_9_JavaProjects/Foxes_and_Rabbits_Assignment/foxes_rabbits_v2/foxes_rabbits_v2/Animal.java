package foxes_rabbits_v2;

import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 * 
 * @author David J. Barnes and Michael Kölling
 * @version 2011.07.31
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    
    /**
     * EXERCISE 12.45 MOVING AGE TO ANIMAL FROM
     * FOXES AND RABBITS
     */
    private int age;
    
    /**
     * EXERCISE 12.46 ADDING GETBREEDINGAGE TO ANIMAL
     */
    abstract protected int getBreedingAge();
    /**
     * EXERCISE 12.47 ADDING GETMAXAGE TO ANIMAL
     */
    abstract protected int getMaxAge();
    /**
     * EXERCISE 12.48 ADDING GETBREEDINGPROB TO ANIMAL
     */
    abstract protected double getBreedingProbablitiy();
    /**
     * EXERCISE 12.48 ADDING GETMAXLITTERSIZE TO ANIMAL
     */
    abstract protected int getMaxLitterSize();
    
    /**
     * EXERCISE 12.52 ADDING GETANIMALTYPE
     */
    abstract protected String getAnimalType();
    
    /**
     * EXERCISE 12.48 ADDING RAND
     */
    // random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        this.field = field;
        //ADDED BECAUSE OF EXERCISE 12.45
        age = 0;
        setLocation(location);
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }

	/**
	 * CREATED FOR EXERCISE 12.45
	 * @return the age
	 */
	protected int getAge() {
		return age;
	}

	/**
	 * CREATED FOR EXERCISE 12.45
	 * @param age the age to set
	 */
	protected void setAge(int age) {
		this.age = age;
	}
	
	/**
	 * EXERCISE 12.46 ADDING CANBREED TO ANIMAL
	 */
    protected boolean canBreed()
    {
        //return age >= BREEDING_AGE;
    	return age >= getBreedingAge();
    }
    
    /**
     * EXERCISE 12.47 ADDED INCREMENTAGE TO ANIMAL
     * Increase the age.
     * This could result in the animal's death
     */
    protected void incrementAge()
    {
        age++;
    	setAge(getAge() + 1);
//        if(age > MAX_AGE) {
//            setDead();
//        }
        if(getAge() > getMaxAge()) {
            setDead();
        }
    }
    
    /**
     * EXERCISE 12.58 MOVING BREED TO ANIMAL
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbablitiy()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }
    
    /**
     * Check whether or not this fox is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFoxes A list to return newly born foxes.
     */
    protected void giveBirth(List<Animal> newAnimal)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            if(getAnimalType() == "BLOB") {
            	Blob blobYoung = new Blob(false, field, loc);
            	newAnimal.add(blobYoung);
            }
            else if(getAnimalType() == "FOX") {
            	Fox foxYoung = new Fox(false, field, loc);
            	newAnimal.add(foxYoung);
            }
            else if(getAnimalType() == "RABBIT") {
            	Rabbit rabbitYoung = new Rabbit(false, field, loc);
            	newAnimal.add(rabbitYoung);
            }
        }
    }
}