package insurance;

import java.util.ArrayList;

public class CarPolicy extends Policy implements Transferrable {
	
	public enum CarInsuranceType {
		LIABILITY, COLLISION, COMPREHENSIVE, GAP 
	}

	private long vin;
	private String make;
	private String model;
	private int year;
	private int mileage;
	private CarInsuranceType type;
	
	public CarPolicy(String policyNumber, double premium, Customer customer, long vin,
			String make, String model, int year, int mileage, CarInsuranceType type) {
		super(policyNumber, premium, customer);
		this.vin = vin;
		this.make = make;
		this.model = model;
		this.year = year;
		this.mileage = mileage;
		this.type = type;
	}

	@Override
	public boolean transfer(Customer newCustomer) {
		this.customer = newCustomer;
		return true;
	}

	public long getVin() {
		return vin;
	}

	public void setVin(long vin) {
		this.vin = vin;
	}
	
	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getMileage() {
		return mileage;
	}

	public void setMileage(int mileage) {
		this.mileage = mileage;
	}

	public CarInsuranceType getType() {
		return type;
	}

	public void setType(CarInsuranceType type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "CarPolicy [vin=" + vin + ", make=" + make + ", model=" + model + ", year=" + year + ", mileage="
				+ mileage + ", type=" + type + ", customer=" + customer + "]";
	}
}
