package insurance;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;

public abstract class Policy implements Displayable {

	private String policyNumber;
	private double premium;
	protected Customer customer;
	private HashMap<String, Claim> claims = new HashMap<String, Claim>();
	
	public Policy(String policyNumber, double premium, Customer customer) {
		this.policyNumber = policyNumber;
		this.premium = premium;
		this.customer = customer;
	}
	
	public void fileClaim(Claim claim) {
		this.claims.put(claim.getClaimID(), claim);
	}
	
	public void fileClaim(String claimID, String firstName, String lastName, Claim.ClaimType claimType, LocalDate claimDate,
			double amountSought, String description) {
		if (claimID == null) {
			// new Claim
			Claim newClaim = new Claim(firstName, lastName, claimType, claimDate, amountSought, description);
			this.claims.put(newClaim.getClaimID(), newClaim);
		}
		else {
			Claim oldClaim = claims.get(claimID);
			if (!oldClaim.getDescription().equals(description)) {
				oldClaim.setDescription(oldClaim.getDescription() + " " + LocalDateTime.now() + ": " + description);
			}
			if (!oldClaim.getFirstName().equals(firstName)) {
				oldClaim.setDescription(oldClaim.getDescription() + " Former first name: " + oldClaim.getFirstName());
				oldClaim.setFirstName(firstName);			
			}
			if (!oldClaim.getLastName().equals(lastName)) {
				oldClaim.setDescription(oldClaim.getDescription() + " Former last name: " + oldClaim.getLastName());
				oldClaim.setLastName(lastName);			
			}
			
			// and maybe more stuff
		}
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public double getPremium() {
		return premium;
	}

	public void setPremium(double premium) {
		this.premium = premium;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public HashMap<String, Claim> getClaims() {
		return claims;
	}

	public void setClaims(HashMap<String, Claim> claims) {
		this.claims = claims;
	}
	
}
