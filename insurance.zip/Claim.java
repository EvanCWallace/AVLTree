package insurance;

import java.time.LocalDate;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Claim implements Displayable {
	
	public enum ClaimType {
		DEFINITIONAL, FACTUAL, POLICY, VALUE
	}

	private String claimID;
	private String firstName;
	private String lastName;
	private ClaimType claimType;
	private LocalDate claimDate;
	private double amountSought;
	private String description;
	
	private static int lastClaimID = 1000;
	
	
	public Claim(String firstName, String lastName, ClaimType claimType, LocalDate claimDate,
			double amountSought, String description) {
		this.claimID = claimType.name().charAt(0) + "-" + ++lastClaimID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.claimType = claimType;
		this.claimDate = claimDate;
		this.amountSought = amountSought;
		this.description = description;
	}

	public String getClaimID() {
		return claimID;
	}

	public void setClaimID(String claimID) {
		this.claimID = claimID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public ClaimType getClaimType() {
		return claimType;
	}

	public void setClaimType(ClaimType claimType) {
		this.claimType = claimType;
	}

	public LocalDate getClaimDate() {
		return claimDate;
	}

	public void setClaimDate(LocalDate claimDate) {
		this.claimDate = claimDate;
	}

	public double getAmountSought() {
		return amountSought;
	}

	public void setAmountSought(double amountSought) {
		this.amountSought = amountSought;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Claim [claimID=" + claimID + ", firstName=" + firstName + ", lastName=" + lastName + ", claimType="
				+ claimType + ", claimDate=" + claimDate + ", amountSought=" + amountSought + ", description="
				+ description + "]";
	}
	
	@Override
	public void display() {
		// Change the default implementation
	    JFrame frame = new JFrame("Florida National Insurance Company");
	    String claimInfo = "Claim #" + this.claimID + " " + this.description;
	    JOptionPane.showMessageDialog(frame, claimInfo);
	}
	
	
}
