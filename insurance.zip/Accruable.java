package insurance;

public interface Accruable {
	
	public abstract void accrue();

}
