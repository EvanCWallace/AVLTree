package insurance;

public class LifePolicy extends Policy implements Accruable, BorrowAgainst {

	private double cashValue;

	public LifePolicy(String policyNumber, double premium, Customer customer, double cashValue) {
		super(policyNumber, premium, customer);
		this.cashValue = cashValue;
	}


	@Override
	public double borrowAgainst(double amountRequested) {
		if (this.cashValue > amountRequested) {
			return amountRequested;
		}
		else {
			return this.cashValue;
		}
	}

	@Override
	public void accrue() {
		this.cashValue += calculateAccrualAmount();		
	}

	private double calculateAccrualAmount() {
		int accrualAmount = 0;
		// TODO code the accrual algorithm
		return accrualAmount;
	}

	@Override
	public String toString() {
		return "LifePolicy [cashValue=" + cashValue + ", customer=" + customer + "]";
	}

}
