package insurance;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public interface Displayable {

	public default void display() {
	    JFrame frame = new JFrame("Florida National Insurance Company");
	    JOptionPane.showMessageDialog(frame, this.toString());
	}
	
}
