package insurance;

import java.time.LocalDate;

public class Driver {

	public static void main(String[] args) {
		createCarPolicyAndClaim();
	}

	private static void createCarPolicyAndClaim() {
		// First make a customer
		Customer hugo = new Customer(132991928L, "Hugo", "Weaving", "weaving@matrix.org", "6092281836");

		// Then make and display a car policy for the customer
		CarPolicy p = new CarPolicy("FDW-192", 200000, hugo, 34219098721431L, "Toyota", "Camry", 
				2020, 23900, CarPolicy.CarInsuranceType.GAP);
		p.display();
		
		// Create a claim and file it against the policy
		Claim claim = new Claim("The", "Oracle", Claim.ClaimType.FACTUAL, LocalDate.now(), 750, "Red pill swalowing.");
		p.fileClaim(claim);
		
		// File an update to the claim
		p.fileClaim("F-1001", "the", "Oracle", Claim.ClaimType.FACTUAL, LocalDate.now(), 750, "Blue pill swalowing.");
		
		// Display all claims for the policy
		p.getClaims().values().forEach(c -> c.display());		
	}
}
