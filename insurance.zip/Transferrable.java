package insurance;

public interface Transferrable {

	public abstract boolean transfer(Customer newCustomer);
}
