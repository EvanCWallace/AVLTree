package insurance;

import java.time.LocalDate;
import java.util.ArrayList;

public class HomePolicy extends Policy implements Transferrable {
	
	
	public enum Coverage {
		CASH_VALUE, REPLACEMENT, ALL_RISK
	}

	String address;
	int zipCode;
	LocalDate constructionDate;
	LocalDate lastInspected;
	Coverage coverage;
	
	public HomePolicy(String policyNumber, double premium, Customer customer, String address,
			int zipCode, LocalDate constructionDate, LocalDate lastInspected, Coverage coverage) {
		super(policyNumber, premium, customer);
		this.address = address;
		this.zipCode = zipCode;
		this.constructionDate = constructionDate;
		this.lastInspected = lastInspected;
		this.coverage = coverage;
	}
	
	@Override
	public boolean transfer(Customer newCustomer) {
		// Do not transfer if no inspection in last year.
		if (this.lastInspected.compareTo(LocalDate.now().minusDays(365)) > 0) {
			this.customer = newCustomer;
			return true;
		}
		return false;
	}
	

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getZipCode() {
		return zipCode;
	}

	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}

	public LocalDate getConstructionDate() {
		return constructionDate;
	}

	public void setConstructionDate(LocalDate constructionDate) {
		this.constructionDate = constructionDate;
	}

	public LocalDate getLastInspected() {
		return lastInspected;
	}

	public void setLastInspected(LocalDate lastInspected) {
		this.lastInspected = lastInspected;
	}

	public Coverage getCoverage() {
		return coverage;
	}

	public void setCoverage(Coverage coverage) {
		this.coverage = coverage;
	}

	@Override
	public String toString() {
		return "HomePolicy [address=" + address + ", zipCode=" + zipCode + ", constructionDate=" + constructionDate
				+ ", lastInspected=" + lastInspected + ", coverage=" + coverage + ", customer=" + customer + "]";
	}	
}
