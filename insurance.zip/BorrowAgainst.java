package insurance;

public interface BorrowAgainst {

	public abstract double borrowAgainst(double amountRequested);

}	
