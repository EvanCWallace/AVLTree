/**
 * 							DESCRIPTION:
 * This is a class file, Movie, for the source folder 'default package'.
 * This file will contain methods to get, set, and display a HashMap
 * collection of movies entered by the user.
 * 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * *					 CLASS IMPORTS:                      * *
 * *														 * *
 * *  														 * *
 * *														 * *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * *					 CLASS VARIABLES:                    * *
 * *														 * *
 * *  #title												 * *
 * *  #released	   											 * *
 * *													     * *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * *                     CLASS METHODS:                      * *
 * * 														 * *
 * *  #Movie(String, String):								 * *
 * * 														 * *
 * *  #getTitle(): String									 * *
 * * 														 * *
 * *  #getReleased(): String                                 * *
 * *														 * *
 * *  +toString(): String            						 * *
 * *														 * *
 * *  							 							 * *
 * * 														 * *
 * *  		                         						 * *
 * * 														 * *
 * *  										 				 * *
 * * 														 * *
 * *  								 						 * *
 * * 														 * *
 * *  										 				 * *
 * * 														 * *
 * *  										 				 * *
 * * 														 * *
 * *  														 * *
 * * 														 * *
 * *  														 * *
 * *  														 * *
 * *  						    							 * *
 * *  														 * *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * 
 * 
 *    @author Evan Wallace 02/03/2021 7:24.47 AM
 */
public class Movie 
{

    protected String title;
    protected String released;
    
    /**
     * This is the constructor for the class Movie
     * 
     * @param title
     * @param released
     */
    protected Movie(String title, String released)
    {
        super();
        this.title = title;
        this.released = released;
    }
    
    /**
     * This method returns the string of the title entered by the user
     * 
     * @return String
     */
    protected String getTitle() 
    {
        return title;
    }

    /**
     * This method returns the string of the released date entered
     * by the user
     * 
     * @return String
     */
    protected String getReleased() 
    {
        return released;
    }

    /**
     * This method is a custom toString() to return a prompt to the user
     * 
     * @return custom
     */
    public String toString() 
    {
    	return this.title + " (" + this.released+") ";
    }
}
