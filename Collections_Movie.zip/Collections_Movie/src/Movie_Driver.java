/**
 *
 * This is the driver of the program. Here the machine will run
 * a scanner for user input three times. The scanner will ask
 * for three parts of information before going onto the next
 * set of input.
 * 
 * Once the user is done entering in the information,
 * the machine will print out a HashMap of the data
 * entered in from the user.
 * 
 * 
 * @author Evan Wallace 02/03/2021 7:24.47 AM
 */

import java.time.LocalDate;

import java.util.HashMap;
import java.util.Scanner;
public class Movie_Driver 
{   
  private static final HashMap <Integer, Movie> movies 
            = new HashMap<Integer, Movie>();
 
  /**
   * Displays the HashMap and out to the Console
   * 
   */
  private static void displayMovies()
  {
      System.out.println("Here is the list of movies: ");
      movies.forEach((key,value) -> {System.out.println(
                                    value.toString() + 
                                    key + " minutes");});
  }
  
  /**
   * 
   * @param args
   */
  public static void main(String[] args)
    {
        populateMovies();
        displayMovies();
    }
  
  
  /**
   * This method has the scanner and loop to store
   * the user's information into the HashMap
   * 
   */
  private static void populateMovies()
  {
    System.out.println("Creating movies");
      int count = 1;
      
      do{
        Scanner textLine = new Scanner(System.in);

        System.out.print("Enter title of movie " + count +": ");
        String title = textLine.nextLine();
        
        System.out.print("Enter the length of movie " + count +": ");
        int duration = textLine.nextInt();
      
        System.out.print("Enter release date of movie " + count +
                           "(YYYY-MM-DD format): ");
        String released = textLine.next();

        movies.put(duration, new Movie(title, released));
        
        System.out.println();
        count++;
       }while(count <=3);
  }
}