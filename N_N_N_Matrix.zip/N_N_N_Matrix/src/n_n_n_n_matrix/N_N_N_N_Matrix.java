/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package n_n_n_n_matrix;

import java.util.Arrays;

/**
 *
 * @author Evan Wallace
 */
public class N_N_N_N_Matrix {

    static boolean flag_FreeVariable = false;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        int length = 3;
        int width = 3;
        int height = 3;
                
        float [][][] matrix = new float [length][width][height];
        
        for(int i = 0; i < length; i++)
            for(int j = 0; j < width; j++)
                for(int k = 0; k < height; k++)
                    matrix [i][j][k] = (int) (Math.random()*10) + 1;
        
        System.out.println("----------Matrix Cube 3---------");
        System.out.println(Arrays.deepToString(matrix));
        System.out.println("----------Matrix Cube 3---------\n\n\n");
        
//        String[] variables = new String [extend];
//        
//        for (char ch = 'a'; ch <= 'z'; ch++)
//        {
//            variables[ch - 'a'] = String.valueOf(ch);
//        }
//        
//        System.out.println("----------Variable List---------");
//        System.out.println(Arrays.deepToString(variables));
//        System.out.println("----------Variable List---------\n\n\n");

        double a1 = matrix[0][0][0];
        System.out.print(a1 + "\t");
        double b1 = matrix[0][0][1];
        System.out.print(b1 + "\t");
        double c1 = matrix[0][0][2];
        System.out.println(c1);
        
        double d1 = matrix[0][1][0];
        System.out.print(d1 + "\t");
        double e1 = matrix[0][1][1];
        System.out.print(e1 + "\t");
        double f1 = matrix[0][1][2];
        System.out.println(f1);
        
        double h1 = matrix[0][2][0];
        System.out.print(h1 + "\t");
        double i1 = matrix[0][2][1];
        System.out.print(i1 + "\t");
        double j1 = matrix[0][2][2];
        System.out.println(j1);
        
        System.out.println();
        
        double a2 = matrix[1][0][0];
        System.out.print(a2 + "\t");
        double b2 = matrix[1][0][1];
        System.out.print(b2 + "\t");
        double c2 = matrix[1][0][2];
        System.out.println(c2);
        
        double d2 = matrix[1][1][0];
        System.out.print(d2 + "\t");
        double e2 = matrix[1][1][1];
        System.out.print(e2 + "\t");
        double f2 = matrix[1][1][2];
        System.out.println(f2);
        
        double h2 = matrix[1][2][0];
        System.out.print(h2 + "\t");
        double i2 = matrix[1][2][1];
        System.out.print(i2 + "\t");
        double j2 = matrix[1][2][2];
        System.out.println(j2);
        
        System.out.println();
        
        double a3 = matrix[2][0][0];
        System.out.print(a3 + "\t");
        double b3 = matrix[2][0][1];
        System.out.print(b3 + "\t");
        double c3 = matrix[2][0][2];
        System.out.println(c3);
        
        double d3 = matrix[2][1][0];
        System.out.print(d3 + "\t");
        double e3 = matrix[2][1][1];
        System.out.print(e3 + "\t");
        double f3 = matrix[2][1][2];
        System.out.println(f3);
        
        double h3 = matrix[2][2][0];
        System.out.print(h3 + "\t");
        double i3= matrix[2][2][1];
        System.out.print(i3 + "\t");
        double j3 = matrix[2][2][2];
        System.out.println(j3);
        
        System.out.println();
        
        System.out.println("---------Right Face Matrix---------\n");
        double [][] RFMatrix1 = {{a1,b1,c1,1}, {d1,e1,f1,1}, {h1, i1, j1,1}};
        System.out.print(Arrays.deepToString(RFMatrix1) + "\n");
        
        double [][] RFMatrix2 = {{a2,b2,c2,1}, {d2,e2,f2,1}, {h2, i2, j2,1}};
        System.out.print(Arrays.deepToString(RFMatrix2) + "\n");
        
        double [][] RFMatrix3 = {{a3,b3,c3,1}, {d3,e3,f3,1}, {h3, i3, j3,1}};
        System.out.print(Arrays.deepToString(RFMatrix3) + "\n");
        
        System.out.println("-----------------------------------");
        
        double [][] RFMatrix4 = {{a1,b1,c1,1}, {a2,b2,c1,1}, {a3,b3,c3,1}};
        System.out.print(Arrays.deepToString(RFMatrix4) + "\n");
        
        double [][] RFMatrix5 = {{d1,e1,f1,1}, {d2,e2,f2,1}, {d3,e3,f3,1}};
        System.out.print(Arrays.deepToString(RFMatrix5) + "\n");
        
        double [][] RFMatrix6 = {{h1,i1,j1,1}, {h2,i2,j2,1}, {h3,i3,j3,1}};
        System.out.print(Arrays.deepToString(RFMatrix6) + "\n");
        System.out.println("--------Right Face Matrix---------\n\n");
        
        System.out.println("--------Left Face Matrix---------\n");
        double [][] LFMatrix1 = {{j1,i1,h1,1},{f1,e1,d1,1}, {c1,b1,a1,1}};
        System.out.print(Arrays.deepToString(LFMatrix1) + "\n");
        
        double [][] LFMatrix2 = {{j2,i2,h2,1},{f2,e2,d2,1}, {c2,b2,a1,1}};
        System.out.print(Arrays.deepToString(LFMatrix2) + "\n");

        double [][] LFMatrix3 = {{j3,i3,h3,1},{f3,e3,d3,1}, {c3,b3,a3,1}};
        System.out.print(Arrays.deepToString(LFMatrix3) + "\n");
        
        System.out.println("-----------------------------------");
        double [][] LFMatrix4 = {{j1,i1,h1,1},{j3,i3,h3,1}, {j3,i3,h3,1}};
        System.out.print(Arrays.deepToString(LFMatrix4) + "\n");
        
        double [][] LFMatrix5 = {{f1,e1,d1,1},{f2,e2,d2,1}, {f3,e3,d3,1}};
        System.out.print(Arrays.deepToString(LFMatrix5) + "\n");

        double [][] LFMatrix6 = {{c1,b1,a1,1},{c2,b2,a2,1}, {c3,b3,a3,1}};
        System.out.print(Arrays.deepToString(LFMatrix6) + "\n");
        System.out.println("--------Left Face Matrix---------\n\n");
        
        System.out.println("--------Back Face Matrix---------\n");
        double [][] BFMatrix1 = {{h1,d1,a1,1}, {i1,e1,b1,1}, {j1,f1,c1,1}};
        System.out.print(Arrays.deepToString(BFMatrix1) + "\n");
        
        double [][] BFMatrix2 = {{h2,d2,a2,1}, {i2,e2,b2,1}, {j2,f2,c2,1}};
        System.out.print(Arrays.deepToString(BFMatrix2) + "\n");
        
        double [][] BFMatrix3 = {{h3,d3,a3,1}, {i3,e3,b3,1}, {j3,f3,c3,1}};
        System.out.print(Arrays.deepToString(BFMatrix3) + "\n");
        
        System.out.println("-----------------------------------");
        
        double [][] BFMatrix4 = {{h1,d1,a1,1}, {h2,d2,a2,1}, {h3,d3,a3,1}};
        System.out.print(Arrays.deepToString(BFMatrix4) + "\n");
        
        double [][] BFMatrix5 = {{i1,e1,b1,1}, {i2,e2,b2,1}, {i3,e3,b3,1}};
        System.out.print(Arrays.deepToString(BFMatrix5) + "\n");
        
        double [][] BFMatrix6 = {{j1,f1,c1,1}, {j2,f2,c2,1}, {j3,f3,c3,1}};
        System.out.print(Arrays.deepToString(BFMatrix6) + "\n");
        System.out.println("--------Back Face Matrix---------\n\n");
        
        System.out.println("--------Front Face Matrix--------\n");
        double [][] FFMatrix1 = {{c1,f1,j1,1}, {b1,e1,i1,1}, {a1,d1,h1,1}};
        System.out.print(Arrays.deepToString(FFMatrix1) + "\n");
        
        double [][] FFMatrix2 = {{c2,f2,j2,1}, {b2,e2,i2,1}, {a2,d2,h2,1}};
        System.out.print(Arrays.deepToString(FFMatrix2) + "\n");
        
        double [][] FFMatrix3 = {{c3,f3,j3,1}, {b3,e3,i3,1}, {a3,d3,h3,1}};
        System.out.print(Arrays.deepToString(FFMatrix3) + "\n");
        
        System.out.println("-----------------------------------");
        
        double [][] FFMatrix4 = {{c1,f1,j1,1}, {c2,f2,j2,1}, {c3,f3,j3,1}};
        System.out.print(Arrays.deepToString(FFMatrix4) + "\n");
        
        double [][] FFMatrix5 = {{b1,e1,i1,1}, {b2,e2,i2,1}, {b3,e3,i3,1}};
        System.out.print(Arrays.deepToString(FFMatrix5) + "\n");
        
        double [][] FFMatrix6 = {{a1,d1,h1,1}, {a2,d2,h2,1}, {a3,d3,h3,1}};
        System.out.print(Arrays.deepToString(FFMatrix6) + "\n");
        System.out.println("--------Front Face Matrix--------\n\n");
        
        System.out.println("--------Top Face Matrix----------\n");
        double [][] TFMatrix1 = {{a1,a2,a3,1}, {d1,d2,d3,1}, {h1,h2,h3,1}};
        System.out.print(Arrays.deepToString(TFMatrix1) + "\n");
        
        double [][] TFMatrix2 = {{b1,b2,b3,1}, {e1,e2,e3,1}, {i1,i2,i3,1}};
        System.out.print(Arrays.deepToString(TFMatrix2) + "\n");
        
        double [][] TFMatrix3 = {{c1,c2,c3,1}, {f1,f2,f3,1}, {j1,j2,j3,1}};
        System.out.print(Arrays.deepToString(TFMatrix3) + "\n");
        
        System.out.println("-----------------------------------");
        
        double [][] TFMatrix4 = {{a1,a2,a3,1}, {b1,b2,b3,1},{c1,c2,c3,1}};
        System.out.print(Arrays.deepToString(TFMatrix4) + "\n");
        
        double [][] TFMatrix5 = {{d1,d2,d3,1}, {e1,e2,e3,1}, {f1,f2,f3,1}};
        System.out.print(Arrays.deepToString(TFMatrix5) + "\n");
        
        double [][] TFMatrix6 = {{h1,h2,h3,1}, {i1,i2,i3,1}, {j1,j2,j3,1}};
        System.out.print(Arrays.deepToString(TFMatrix6) + "\n");
        
        System.out.println("--------Top Face Matrix----------\n\n");
       
        System.out.println("--------Bottom Face Matrix-------\n");
        double [][] BMFMatrix1 = {{c1,c2,c3,1}, {f1,f2,f3,1}, {j1,j2,j3,1}};
        System.out.print(Arrays.deepToString(BMFMatrix1) + "\n");
        
        double [][] BMFMatrix2 = {{b1,b2,b3,1}, {e1,e2,e3,1}, {i1,i2,i3,1}};
        System.out.print(Arrays.deepToString(BMFMatrix2) + "\n");
        
        double [][] BMFMatrix3 = {{a1,a2,a3,1}, {d1,d2,d3,1}, {h1,h2,h3,1}};
        System.out.print(Arrays.deepToString(BMFMatrix3) + "\n");
        
        System.out.println("-----------------------------------");
        
        double [][] BMFMatrix4 = {{c1,c2,c3,1}, {b1,b2,b3,1},{a1,a2,a3,1}};
        System.out.print(Arrays.deepToString(BMFMatrix4) + "\n");
        
        double [][] BMFMatrix5 = {{f1,f2,f3,1}, {e1,e2,e3,1}, {d1,d2,d3,1}};
        System.out.print(Arrays.deepToString(BMFMatrix5) + "\n");
        
        double [][] BMFMatrix6 = {{j1,j2,j3,1}, {i1,i2,i3,1}, {h1,h2,h3,1}};
        System.out.print(Arrays.deepToString(BMFMatrix6) + "\n");
        System.out.println("--------Bottom Face Matrix-------\n\n");
        
        System.out.println("--------RREF Right Face Matrix---------");
        System.out.println(RREF_Matrix(RFMatrix1));
        System.out.println(RREF_Matrix(RFMatrix2));
        System.out.println(RREF_Matrix(RFMatrix3));
        System.out.println("-----------------------------------");
        System.out.println(RREF_Matrix(RFMatrix4));
        System.out.println(RREF_Matrix(RFMatrix5));
        System.out.println(RREF_Matrix(RFMatrix6));
        System.out.println("--------RREF Right Face Matrix---------\n\n");
        
        System.out.println("--------RREF Left Face Matrix---------");
        System.out.println(RREF_Matrix(LFMatrix1));
        System.out.println(RREF_Matrix(LFMatrix2));
        System.out.println(RREF_Matrix(LFMatrix3));
        System.out.println("-----------------------------------");
        System.out.println(RREF_Matrix(LFMatrix4));
        System.out.println(RREF_Matrix(LFMatrix5));
        System.out.println(RREF_Matrix(LFMatrix6));
        
        System.out.println("--------RREF Left Face Matrix---------\n\n");
        
        System.out.println("--------RREF Back Face Matrix---------");
        System.out.println(RREF_Matrix(BFMatrix1));
        System.out.println(RREF_Matrix(BFMatrix2));
        System.out.println(RREF_Matrix(BFMatrix3));
        System.out.println("-----------------------------------");
        System.out.println(RREF_Matrix(BFMatrix4));
        System.out.println(RREF_Matrix(BFMatrix5));
        System.out.println(RREF_Matrix(BFMatrix6));
        System.out.println("--------RREF Back Face Matrix---------\n\n");
        
        System.out.println("--------RREF Front Face Matrix--------");
        System.out.println(RREF_Matrix(FFMatrix1));
        System.out.println(RREF_Matrix(FFMatrix2));
        System.out.println(RREF_Matrix(FFMatrix3));
        System.out.println("-----------------------------------");
        System.out.println(RREF_Matrix(FFMatrix4));
        System.out.println(RREF_Matrix(FFMatrix5));
        System.out.println(RREF_Matrix(FFMatrix6));
        System.out.println("--------RREF Front Face Matrix--------\n\n");

        System.out.println("--------RREF Top Face Matrix----------");
        System.out.println(RREF_Matrix(TFMatrix1));
        System.out.println(RREF_Matrix(TFMatrix2));
        System.out.println(RREF_Matrix(TFMatrix3));
        System.out.println("-----------------------------------");
        System.out.println(RREF_Matrix(TFMatrix4));
        System.out.println(RREF_Matrix(TFMatrix5));
        System.out.println(RREF_Matrix(TFMatrix6));
        System.out.println("--------RREF Top Face Matrix----------\n\n");

        
        System.out.println("--------RREF Bottom Face Matrix-------");
        System.out.println(RREF_Matrix(BMFMatrix1));
        System.out.println(RREF_Matrix(BMFMatrix2));
        System.out.println(RREF_Matrix(BMFMatrix3));
        System.out.println("-----------------------------------");
        System.out.println(RREF_Matrix(BMFMatrix4));
        System.out.println(RREF_Matrix(BMFMatrix5));
        System.out.println(RREF_Matrix(BMFMatrix6));
        System.out.println("--------RREF Bottom Face Matrix-------\n\n");
    }
    
    
//         h := 1 /* Initialization of the pivot row */
//         k := 1 /* Initialization of the pivot column */
//         while h ≤ m and k ≤ n
//           /* Find the k-th pivot: */
//           i_max := argmax (i = h ... m, abs(A[i, k]))
//           if A[i_max, k] = 0
//             /* No pivot in this column, pass to next column */
//             k := k+1
//           else
//              swap rows(h, i_max)
//              /* Do for all rows below pivot: */
//              for i = h + 1 ... m:
//                 f := A[i, k] / A[h, k]
//                 /* Fill with zeros the lower part of pivot column: */
//                 A[i, k]  := 0
//                 /* Do for all remaining elements in current row: */
//                 for j = k + 1 ... n:
//                    A[i, j] := A[i, j] - A[h, j] * f
//              /* Increase pivot row and column */
//              h := h+1 
//              k := k+1

    public static String RREF_Matrix(double [][] matrix)
    {
        int n = matrix.length;
        float [] x = new float [n];
        
        //Pivotization of the Matrix
        for(int i = 0; i < n; i++)
        {
            for(int k = i + 1; k < n; k++)
            {
                if(Math.abs(matrix [i][i]) < Math.abs(matrix[k][i]))
                {
                    for(int j = 0; j <= n; j++)
                    {
                        double temp = matrix [i][j];
                        matrix[i][j] = matrix[k][j];
                        matrix[k][j] = temp;             
                    }
                }
            }
        }
        //Pivotization of the Matrix
        
        //Gauss-Elimination
        for (int i = 0; i < n-1; i++)
        {            
            //loop to perform the gauss elimination
            for (int k = i+1; k < n; k++)
            {
                double t = matrix[k][i] / matrix[i][i];
                for (int j = 0; j <= n; j++)
                {
                    matrix[k][j] = matrix[k][j] - (t*matrix[i][j]);    //make the elements below the pivot elements equal to zero or elimnate the variables
                }
            }
        }
        //Gauss-Elimination
        
        //System.out.println(Arrays.deepToString(matrix) + "Look Here");
        if((matrix[0][0] == 0) || (matrix[1][1] == 0) || (matrix[2][2] == 0))
        {
            flag_FreeVariable = true;
            System.out.println("Free Variables");
        }
        else
        {
            System.out.println("Basic Variables");
        }
        //System.out.println(Arrays.deepToString(matrix) + "Look Here");
        
        if(flag_FreeVariable)
        {
            flag_FreeVariable = false;
            return Arrays.deepToString(matrix) + "HERE";
        }
        
        //Back Substitution
        for(int i = n-1; i >= 0; i--)
        {
            x[i] = (float) matrix[i][n];
            
            for(int j = i+1; j < n; j++)
            {                
                x[i] = x[i] - (float) (matrix[i][j] * x[j]);
            }
            
            x[i] = (float) (x[i]/matrix[i][i]);
            
        }
        //Back Substitution
        
        
        return Arrays.toString(x);
    }
}
