package headfirst.observer.weather;

import java.util.*;

import headfirst.beansobserver.*;
import headfirst.beansobserver.Observable;

public class WeatherData implements Subject {
	private ArrayList<Observer> observersArrayList;
	private float temperature;
	private float humidity;
	private float pressure;
	
	private BeansObservable observable;
	
	
	static class FriendlyObserver extends headfirst.beansobserver.BeansObserver
	{
		private headfirst.beansobserver.BeansObserver wrappedObserver;
		
		public FriendlyObserver(headfirst.beansobserver.BeansObserver wrappedObserver)
		{
			this.wrappedObserver = wrappedObserver;
		}
		
		@Override
		public void update(Observable source, Object data) {
			// TODO Auto-generated method stub
			
		}
		
	}
	
	public WeatherData() {
		observersArrayList = new ArrayList<Observer>();
	
		observable = new BeansObservable();
	}
	
	public void registerObserver(Observer o) {
		FriendlyObserver wrapper = new FriendlyObserver((BeansObserver)o);
		observable.addObserver(wrapper);
		
		observersArrayList.add(o);
	}
	
	public void removeObserver(Observer o) {
		int i = observersArrayList.indexOf(o);
		if(i >= 0)
		{
			observersArrayList.remove(i);
		}
		
		FriendlyObserver wrapper = new FriendlyObserver((BeansObserver) o);
		observable.removeObserver(wrapper);
	}
	
	public void notifyObservers() {
		for (int i = 0; i < observersArrayList.size(); i++) {
			Observer observer = (Observer)observersArrayList.get(i);
			observer.update(temperature, humidity, pressure);
		}
		
		observable.notifyObservers(observersArrayList);
	}
	
	public void measurementsChanged() {
		notifyObservers();
	}
	
	public void setMeasurements(float temperature, float humidity, float pressure) {
		this.temperature = temperature;
		this.humidity = humidity;
		this.pressure = pressure;
		measurementsChanged();
	}
	
	public float getTemperature() {
		return temperature;
	}
	
	public float getHumidity() {
		return humidity;
	}
	
	public float getPressure() {
		return pressure;
	}

}
